# Instrucción para Replit Agent — Piccolo TPV Entrega 2

Trabaja sobre el proyecto existente de la Entrega 1. No cambies el stack: Vue 3 + Vite, Node.js + Express, PostgreSQL y Socket.io.

## Objetivo
Implementar el flujo completo desde la tablet del camarero hasta los KDS de producción y el KDS de Pase.

## 1. Base de datos
Ejecuta `database/migrations/002_comandas_kds.sql` y conserva los datos existentes.

## 2. Backend
Añade estas rutas protegidas por JWT:

- `GET /api/categories`
- `GET /api/categories/:categoryId/products`
- `GET /api/tables/:tableId/order`
- `POST /api/orders/:orderId/items`
- `DELETE /api/order-items/:itemId` solo si está en estado draft
- `POST /api/orders/:orderId/send`
- `GET /api/kds/:zone`
- `PATCH /api/kitchen-tasks/:taskId/status`
- `POST /api/orders/:orderId/pase`

Al abrir una mesa debe crearse un pedido activo y devolver `{table, order}`.

Al enviar una comanda:
1. Seleccionar solo líneas draft.
2. Crear una `kitchen_task` por línea con su `prep_zone`.
3. Cambiar las líneas a sent.
4. Cambiar el pedido a sent.
5. Emitir `kds:refresh` por Socket.io.

Estados permitidos de producción:
- new
- preparing
- ready
- collected
- served
- cancelled

Cuando todas las tareas de un pedido estén listas, cambiar el pedido a ready y emitir `waiter:order-ready` con orderId, tableId, tableName y employeeId.

## 3. Tablet del camarero
Crear ruta `/pedido/:tableId/:orderId`.

Diseño táctil para tablet:
- Categorías arriba.
- Productos como botones grandes.
- Ticket actual a la derecha en horizontal y debajo en pantalla estrecha.
- Botón Enviar comanda.
- Total visible.
- Quitar una línea solo antes de enviarla.
- Mostrar estado de cada línea.

Desde el plano de mesas:
- Mesa libre: abrir mesa, crear pedido y entrar en su pantalla.
- Mesa ocupada: recuperar pedido abierto y entrar.

## 4. KDS por zona
Crear ruta `/kds/:zone` para:
- cocina
- pizza
- ensalada
- barra
- pase

Cada tarjeta de producción debe mostrar:
- Mesa
- Camarero
- Cantidad y producto
- Minutos transcurridos
- Estado
- Botón Preparando
- Botón Listo

Actualizar automáticamente al recibir `kds:refresh`.

## 5. KDS de Pase
Agrupar por pedido/mesa los platos de todas las zonas.
Mostrar:
- Mesa
- Camarero responsable
- Platos listos / total
- Barra de progreso
- Tiempo de espera
- Mensaje MESA COMPLETA cuando todos estén listos
- Botón Recogido
- Botón Servido

Al pulsar Recogido, registrar `collected_at` y empleado que recoge si se añade el campo.
Al pulsar Servido:
- Marcar tareas served
- Marcar pedido served
- Marcar mesa served
- Emitir actualizaciones a tablets y plano de mesas

## 6. Notificación básica en tablet
Cuando llegue `waiter:order-ready`, mostrar un aviso visible y reproducir un sonido únicamente si el pedido pertenece al camarero conectado. Texto: `Mesa X lista para recoger`.

## 7. Reglas
- No borrar funciones de la Entrega 1.
- Consultas SQL parametrizadas.
- Transacciones al abrir mesa y enviar comanda.
- Manejo de errores con mensajes en español.
- Interfaz responsive y botones grandes.
- No implementar todavía pagos ni Verifactu.

## 8. Prueba obligatoria
Demostrar este recorrido:
1. Login Admin 1234.
2. Abrir Mesa 1.
3. Añadir Pizza Diavola, Ensalada César, Entrecot y Coca-Cola.
4. Enviar comanda.
5. Ver cada producto en su KDS correcto.
6. Marcar cada uno preparando y listo.
7. Ver Mesa 1 completa en KDS Pase.
8. Marcar recogido y servido.
9. Confirmar que la mesa aparece como servida en la tablet.

Al terminar, crea `ENTREGA_2_COMPLETADA.md` indicando archivos modificados, prueba realizada y cualquier limitación pendiente.
