# Piccolo TPV — Entrega 4: Cobro, caja y ticket

Continúa sobre la Entrega 3 sin eliminar ninguna función existente.

## Objetivo
Implementar un cobro básico real y cómodo para tablet y ordenador.

## Funciones obligatorias

1. Añadir pantalla `/cobro/:orderId`.
2. Mostrar:
   - mesa;
   - camarero;
   - líneas de pedido;
   - subtotal;
   - impuestos;
   - total;
   - total pagado;
   - importe pendiente.
3. Métodos iniciales:
   - efectivo;
   - tarjeta manual;
   - Bizum.
4. Permitir pago completo y pago mixto.
5. No permitir cobrar más del total salvo en efectivo para calcular cambio.
6. Mostrar cambio que debe devolverse.
7. Crear el ticket cuando el importe pendiente llegue a cero.
8. Cambiar el pedido a `paid`.
9. Liberar la mesa automáticamente.
10. Mantener un historial de pagos.
11. Añadir apertura de caja:
    - empleado;
    - fondo inicial;
    - fecha y hora.
12. Añadir cierre de caja:
    - efectivo esperado;
    - efectivo contado;
    - diferencia;
    - ventas por método.
13. Añadir entradas y salidas manuales de caja con motivo obligatorio.
14. Crear una vista imprimible de ticket de 80 mm.
15. Preparar un botón para enviar el ticket por correo, sin enviar todavía.
16. Registrar en auditoría:
    - apertura;
    - cobro;
    - anulación;
    - movimiento;
    - cierre.
17. Diseñar todo para tablet Android, con botones grandes.
18. Aplicar la migración:
    `database/migrations/004_cobros_caja_tickets.sql`.

## Rutas backend recomendadas

- `POST /api/cash-sessions/open`
- `GET /api/cash-sessions/current`
- `POST /api/cash-sessions/:id/movements`
- `POST /api/cash-sessions/:id/close`
- `GET /api/orders/:id/payment-summary`
- `POST /api/orders/:id/payments`
- `GET /api/orders/:id/ticket`
- `GET /api/cash-sessions/:id/summary`

## Reglas importantes

- Todas las operaciones económicas deben ejecutarse en transacciones SQL.
- Nunca borrar un pago completado.
- Una corrección debe quedar como anulación o contramovimiento.
- Usar decimales exactos; no usar números flotantes para dinero.
- Bloquear doble cobro por pulsaciones repetidas.
- Mostrar confirmación antes de finalizar.
- El pedido solo se cierra cuando el pendiente sea exactamente cero.
- El código debe quedar preparado para Verifactu en una entrega posterior.

## Prueba final

1. Abrir caja con 100 €.
2. Abrir una mesa y enviar una comanda.
3. Cobrar una parte en tarjeta y otra en efectivo.
4. Mostrar el cambio.
5. Emitir ticket.
6. Liberar la mesa.
7. Registrar una salida de caja.
8. Cerrar caja y mostrar la diferencia.
9. Comprobar que todo queda guardado tras recargar.
