# Piccolo TPV — Entrega 3

## Objetivo
Completar el trabajo real de los camareros con tablet e integrar modificadores, observaciones, alérgenos y avisos del KDS de Pase.

## Funciones obligatorias

1. En la pantalla de pedido, cada línea debe tener el botón **Editar**.
2. El camarero podrá añadir:
   - modificadores del producto;
   - observaciones libres;
   - punto de cocción;
   - extras con suplemento;
   - aviso de alergia o requisito especial.
3. Las alergias deben mostrarse en rojo y con el texto **ALERGIA** en TPV, KDS de producción y KDS de Pase.
4. La comanda debe conservar la mesa, camarero, hora, zona de preparación y modificaciones.
5. Cuando todos los platos de una mesa estén listos, crear una notificación en tiempo real para la tablet del camarero responsable.
6. La tablet debe mostrar un aviso visible: **Mesa X lista para recoger**, con vibración cuando el dispositivo lo permita.
7. El camarero podrá confirmar **Recogido** y **Servido**.
8. Registrar usuario, fecha y hora de cada cambio.
9. Mantener compatibilidad con tablets Android en horizontal y vertical.
10. No eliminar ninguna función de las Entregas 1 y 2.

## Endpoints que se deben añadir

- `GET /api/products/:productId/modifiers`
- `PATCH /api/order-items/:itemId/details`
- `GET /api/notifications/unread`
- `PATCH /api/notifications/:notificationId/read`

## Eventos Socket.io

- `order:item-updated`
- `waiter:<employeeId>:notification`
- `waiter:order-ready`
- `kds:refresh`

## Pruebas obligatorias

1. Abrir una mesa desde tablet.
2. Añadir una pizza con extra queso y sin cebolla.
3. Añadir un entrecot al punto.
4. Añadir una alergia grave a frutos secos.
5. Enviar la comanda.
6. Ver las modificaciones en Cocina/Pizza.
7. Ver la alergia destacada en rojo.
8. Marcar todos los platos como listos.
9. Ver el aviso en la tablet del camarero.
10. Marcar recogido y servido.

Al terminar, deja el proyecto funcionando y explica únicamente las variables de entorno y los errores corregidos.
