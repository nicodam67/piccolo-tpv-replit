# Entrega 4 — Cobros, caja y tickets

Esta entrega convierte el flujo de servicio en un ciclo completo:

**abrir mesa → tomar comanda → producir → recoger → servir → cobrar → emitir ticket → liberar mesa**

Incluye la especificación para:

- efectivo, tarjeta y Bizum;
- pago mixto;
- cálculo de cambio;
- apertura y cierre de caja;
- movimientos de caja;
- ticket imprimible de 80 mm;
- historial y auditoría;
- preparación futura para Verifactu.

## Instalación en Replit

1. Importa el ZIP completo.
2. Ejecuta la migración `004_cobros_caja_tickets.sql`.
3. Pega `PROMPT_PARA_REPLIT_ENTREGA_4.md` en Replit Agent.
4. Pide al Agent que ejecute todas las pruebas indicadas.
