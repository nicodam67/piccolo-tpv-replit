CREATE TABLE IF NOT EXISTS categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID NOT NULL REFERENCES categories(id),
  name VARCHAR(150) NOT NULL,
  price NUMERIC(10,2) NOT NULL,
  prep_zone VARCHAR(30) NOT NULL CHECK (prep_zone IN ('cocina','pizza','ensalada','barra')),
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price NUMERIC(10,2) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'draft',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS kitchen_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  order_item_id UUID NOT NULL REFERENCES order_items(id) ON DELETE CASCADE,
  prep_zone VARCHAR(30) NOT NULL,
  product_name VARCHAR(150) NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  status VARCHAR(30) NOT NULL DEFAULT 'new',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ready_at TIMESTAMPTZ,
  collected_at TIMESTAMPTZ,
  served_at TIMESTAMPTZ
);

ALTER TABLE orders ADD COLUMN IF NOT EXISTS sent_at TIMESTAMPTZ;

DO $$
DECLARE
  c1 UUID; c2 UUID; c3 UUID; c4 UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM categories) THEN
    INSERT INTO categories(name,sort_order) VALUES ('Pizzas',1) RETURNING id INTO c1;
    INSERT INTO categories(name,sort_order) VALUES ('Cocina',2) RETURNING id INTO c2;
    INSERT INTO categories(name,sort_order) VALUES ('Ensaladas',3) RETURNING id INTO c3;
    INSERT INTO categories(name,sort_order) VALUES ('Bebidas y cafés',4) RETURNING id INTO c4;

    INSERT INTO products(category_id,name,price,prep_zone) VALUES
      (c1,'Pizza Margherita',11.50,'pizza'),
      (c1,'Pizza Diavola',13.50,'pizza'),
      (c1,'Pizza Prosciutto',13.00,'pizza'),
      (c2,'Pasta carbonara',14.50,'cocina'),
      (c2,'Lasaña',15.00,'cocina'),
      (c2,'Entrecot al punto',21.50,'cocina'),
      (c3,'Ensalada César',12.50,'ensalada'),
      (c3,'Ensalada Caprese',11.50,'ensalada'),
      (c4,'Agua',2.20,'barra'),
      (c4,'Coca-Cola',2.80,'barra'),
      (c4,'Copa de vino',3.50,'barra'),
      (c4,'Café',1.60,'barra');
  END IF;
END $$;
