# Piccolo TPV — Entrega 2: Comandas y KDS

Esta entrega amplía la Entrega 1 con el flujo operativo básico del restaurante.

## Incluye
- Categorías y productos.
- Apertura de mesa y pedido activo.
- Añadir productos a la comanda.
- Enviar comanda a producción.
- Separación por Cocina, Pizza, Ensalada y Barra.
- KDS por zona.
- KDS de Pase / Recogida.
- Estados: nuevo, preparando, listo, recogido y servido.
- Eventos en tiempo real con Socket.io.

## Instalación
1. Instala primero la Entrega 1.
2. Ejecuta `database/migrations/002_comandas_kds.sql` en PostgreSQL.
3. Sustituye los archivos backend y frontend incluidos en esta entrega.
4. Reinicia Replit.

## Rutas KDS
- `/kds/cocina`
- `/kds/pizza`
- `/kds/ensalada`
- `/kds/barra`
- `/kds/pase`

## Usuario de prueba
- Admin
- PIN 1234

## Siguiente entrega
Modificadores, observaciones, alérgenos, avisos en tablet, división de cuenta y cobro básico.
