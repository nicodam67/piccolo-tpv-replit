# Entrega 3 — Tablets, modificadores y alérgenos

Este paquete continúa sobre la Entrega 2. Incluye la migración SQL y el documento de instrucciones para que Replit Agent implemente y pruebe:

- edición de líneas de pedido;
- modificadores y suplementos;
- observaciones;
- alertas de alérgenos;
- notificaciones en la tablet del camarero;
- confirmación de recogida y servicio.

## Orden en Replit

1. Importar este ZIP sobre un proyecto nuevo.
2. Abrir `PROMPT_PARA_REPLIT_ENTREGA_3.md`.
3. Copiar su contenido en Replit Agent.
4. Pedir al Agent que ejecute la migración `database/migrations/003_tablets_modificadores_alergenos.sql`.
5. Probar el flujo completo indicado en el documento.

## Próxima entrega

División de cuenta, cobro básico, efectivo, tarjeta, Bizum, ticket y caja.
