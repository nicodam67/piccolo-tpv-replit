CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS employees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  role VARCHAR(30) NOT NULL CHECK (role IN ('admin','supervisor','waiter','cashier','production')),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS employee_pins (
  employee_id UUID PRIMARY KEY REFERENCES employees(id) ON DELETE CASCADE,
  pin_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS room_zones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) NOT NULL,
  type VARCHAR(30) NOT NULL DEFAULT 'dining',
  sort_order INTEGER NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS restaurant_tables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id UUID NOT NULL REFERENCES room_zones(id) ON DELETE CASCADE,
  name VARCHAR(50) NOT NULL,
  capacity INTEGER NOT NULL DEFAULT 4,
  status VARCHAR(30) NOT NULL DEFAULT 'free',
  x INTEGER NOT NULL DEFAULT 0,
  y INTEGER NOT NULL DEFAULT 0,
  shape VARCHAR(20) NOT NULL DEFAULT 'square',
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_id UUID REFERENCES restaurant_tables(id),
  employee_id UUID REFERENCES employees(id),
  order_type VARCHAR(30) NOT NULL DEFAULT 'table',
  status VARCHAR(30) NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  employee_id UUID REFERENCES employees(id),
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

DO $$
DECLARE
  admin_id UUID;
  zone1 UUID;
  zone2 UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM employees WHERE name = 'Admin') THEN
    INSERT INTO employees (name, role) VALUES ('Admin', 'admin') RETURNING id INTO admin_id;
    INSERT INTO employee_pins (employee_id, pin_hash)
    VALUES (admin_id, crypt('1234', gen_salt('bf')));
  END IF;

  IF NOT EXISTS (SELECT 1 FROM room_zones) THEN
    INSERT INTO room_zones (name, type, sort_order)
    VALUES ('Salón 1', 'dining', 1) RETURNING id INTO zone1;

    INSERT INTO room_zones (name, type, sort_order)
    VALUES ('Terraza', 'terrace', 2) RETURNING id INTO zone2;

    INSERT INTO restaurant_tables (zone_id, name, capacity, status)
    VALUES
      (zone1, 'Mesa 1', 4, 'free'),
      (zone1, 'Mesa 2', 4, 'free'),
      (zone1, 'Mesa 3', 2, 'free'),
      (zone1, 'Mesa 4', 6, 'free'),
      (zone2, 'T1', 4, 'free'),
      (zone2, 'T2', 4, 'free'),
      (zone2, 'T3', 2, 'free');
  END IF;
END $$;
