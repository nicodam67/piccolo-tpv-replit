# Piccolo TPV — Entrega 1

Base funcional preparada para Replit o ejecución local.

## Incluye
- Backend Node.js + Express
- Frontend Vue 3 + Vite
- PostgreSQL
- Socket.io
- Login por PIN
- Zonas y mesas
- Estructura inicial para pedidos y KDS

## Arranque rápido en Replit

1. Crea un Repl nuevo importando este proyecto.
2. Añade una base de datos PostgreSQL.
3. Crea estas variables:
   - `DATABASE_URL`
   - `JWT_SECRET`
4. Ejecuta el SQL de `database/schema.sql`.
5. En la raíz ejecuta:
   ```bash
   npm run install:all
   npm run dev
   ```

## Usuario de prueba
- Nombre: Admin
- PIN: `1234`

## Siguiente entrega
- Pedido de mesa
- Envío de comandas por zona
- KDS Cocina, Pizza, Ensalada, Barra y Pase
