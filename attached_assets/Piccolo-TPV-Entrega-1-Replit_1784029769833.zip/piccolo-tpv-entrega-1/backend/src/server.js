import "dotenv/config";
import http from "http";
import { Server } from "socket.io";
import { createApp } from "./app.js";

const port = Number(process.env.PORT || 3000);
const server = http.createServer();

const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL?.split(",") || true,
    credentials: true,
  },
});

const app = createApp(io);
server.on("request", app);

io.on("connection", (socket) => {
  console.log("Dispositivo conectado:", socket.id);
});

server.listen(port, "0.0.0.0", () => {
  console.log(`Backend Piccolo TPV en puerto ${port}`);
});
