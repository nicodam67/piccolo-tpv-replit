import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { query } from "./db.js";
import { requireAuth } from "./auth.js";

export function createApp(io) {
  const app = express();

  app.use(cors({
    origin: process.env.FRONTEND_URL?.split(",") || true,
    credentials: true,
  }));
  app.use(express.json());

  app.get("/api/health", async (_req, res) => {
    try {
      await query("SELECT 1");
      res.json({ ok: true, database: "connected" });
    } catch (error) {
      res.status(500).json({ ok: false, error: error.message });
    }
  });

  app.post("/api/auth/pin", async (req, res) => {
    const { employeeId, pin } = req.body;

    if (!employeeId || !pin) {
      return res.status(400).json({ error: "Empleado y PIN son obligatorios" });
    }

    const result = await query(
      `SELECT e.id, e.name, e.role, ep.pin_hash
       FROM employees e
       JOIN employee_pins ep ON ep.employee_id = e.id
       WHERE e.id = $1 AND e.active = TRUE`,
      [employeeId]
    );

    const employee = result.rows[0];
    if (!employee || !(await bcrypt.compare(pin, employee.pin_hash))) {
      return res.status(401).json({ error: "PIN incorrecto" });
    }

    const token = jwt.sign(
      { id: employee.id, name: employee.name, role: employee.role },
      process.env.JWT_SECRET,
      { expiresIn: "12h" }
    );

    res.json({
      token,
      employee: { id: employee.id, name: employee.name, role: employee.role }
    });
  });

  app.get("/api/employees/login-list", async (_req, res) => {
    const result = await query(
      "SELECT id, name, role FROM employees WHERE active = TRUE ORDER BY name"
    );
    res.json(result.rows);
  });

  app.get("/api/zones", requireAuth, async (_req, res) => {
    const result = await query(
      "SELECT id, name, type FROM room_zones WHERE active = TRUE ORDER BY sort_order, name"
    );
    res.json(result.rows);
  });

  app.get("/api/zones/:zoneId/tables", requireAuth, async (req, res) => {
    const result = await query(
      `SELECT id, name, capacity, status, x, y, shape
       FROM restaurant_tables
       WHERE zone_id = $1 AND active = TRUE
       ORDER BY name`,
      [req.params.zoneId]
    );
    res.json(result.rows);
  });

  app.post("/api/tables/:tableId/open", requireAuth, async (req, res) => {
    const client = await query(
      `UPDATE restaurant_tables
       SET status = 'occupied'
       WHERE id = $1 AND status = 'free'
       RETURNING *`,
      [req.params.tableId]
    );

    if (!client.rows[0]) {
      return res.status(409).json({ error: "La mesa no está libre" });
    }

    const table = client.rows[0];
    io.emit("table:updated", table);
    res.json(table);
  });

  app.use((err, _req, res, _next) => {
    console.error(err);
    res.status(500).json({ error: "Error interno del servidor" });
  });

  return app;
}
