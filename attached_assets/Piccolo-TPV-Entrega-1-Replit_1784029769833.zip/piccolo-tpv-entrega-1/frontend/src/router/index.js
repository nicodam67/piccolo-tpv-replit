import { createRouter, createWebHistory } from "vue-router";
import LoginView from "../views/LoginView.vue";
import TablesView from "../views/TablesView.vue";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", component: LoginView },
    { path: "/mesas", component: TablesView, meta: { auth: true } },
  ],
});

router.beforeEach((to) => {
  if (to.meta.auth && !localStorage.getItem("token")) return "/";
});

export default router;
