<script setup>
import { onMounted, ref } from "vue";
import { api } from "../api.js";

const zones = ref([]);
const tables = ref([]);
const selectedZone = ref(null);
const employee = JSON.parse(localStorage.getItem("employee") || "{}");

async function loadZones() {
  zones.value = (await api.get("/zones")).data;
  if (zones.value.length) await selectZone(zones.value[0]);
}

async function selectZone(zone) {
  selectedZone.value = zone;
  tables.value = (await api.get(`/zones/${zone.id}/tables`)).data;
}

async function openTable(table) {
  if (table.status !== "free") return;
  const { data } = await api.post(`/tables/${table.id}/open`);
  Object.assign(table, data);
}

function logout() {
  localStorage.clear();
  location.href = "/";
}

onMounted(loadZones);
</script>

<template>
  <main class="app-shell">
    <header>
      <div>
        <h1>Plano de mesas</h1>
        <p>{{ employee.name }}</p>
      </div>
      <button @click="logout">Salir</button>
    </header>

    <nav class="zones">
      <button
        v-for="zone in zones"
        :key="zone.id"
        :class="{ active: selectedZone?.id === zone.id }"
        @click="selectZone(zone)"
      >
        {{ zone.name }}
      </button>
    </nav>

    <section class="tables-grid">
      <button
        v-for="table in tables"
        :key="table.id"
        class="table-card"
        :class="table.status"
        @click="openTable(table)"
      >
        <strong>{{ table.name }}</strong>
        <span>{{ table.capacity }} personas</span>
        <small>{{ table.status }}</small>
      </button>
    </section>
  </main>
</template>
