<script setup>
import { onMounted, ref } from "vue";
import { useRouter } from "vue-router";
import { api } from "../api.js";

const router = useRouter();
const employees = ref([]);
const selected = ref(null);
const pin = ref("");
const error = ref("");

onMounted(async () => {
  try {
    employees.value = (await api.get("/employees/login-list")).data;
  } catch {
    error.value = "No se pudo conectar con el servidor.";
  }
});

async function login() {
  error.value = "";
  try {
    const { data } = await api.post("/auth/pin", {
      employeeId: selected.value,
      pin: pin.value,
    });
    localStorage.setItem("token", data.token);
    localStorage.setItem("employee", JSON.stringify(data.employee));
    router.push("/mesas");
  } catch (e) {
    error.value = e.response?.data?.error || "Error al iniciar sesión";
  }
}
</script>

<template>
  <main class="login-page">
    <section class="card login-card">
      <h1>Piccolo TPV</h1>
      <p>Selecciona tu nombre e introduce tu PIN</p>

      <div class="employee-grid">
        <button
          v-for="employee in employees"
          :key="employee.id"
          :class="{ selected: selected === employee.id }"
          @click="selected = employee.id"
        >
          {{ employee.name }}
          <small>{{ employee.role }}</small>
        </button>
      </div>

      <input v-model="pin" maxlength="4" inputmode="numeric" type="password" placeholder="PIN de 4 dígitos" />
      <button class="primary" :disabled="!selected || pin.length !== 4" @click="login">
        Entrar
      </button>
      <p class="error" v-if="error">{{ error }}</p>
    </section>
  </main>
</template>
